#!/usr/bin/env python3
import asyncio
import json
import websockets
import ssl

# Store connected clients: {client_id: websocket}
clients = {}


async def handler(websocket):
    client_id = id(websocket)
    clients[client_id] = websocket
    print(f"Client {client_id} connected")
    try:
        async for message in websocket:
            data = json.loads(message)
            # Relay to all other clients
            for cid, ws in clients.items():
                if cid != client_id:
                    await ws.send(json.dumps(data))
    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        del clients[client_id]
        print(f"Client {client_id} disconnected")


async def main():
    # Use the self‑signed certificate
    ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ssl_context.load_cert_chain("cert.pem", "key.pem")

    async with websockets.serve(handler, "0.0.0.0", 8765, ssl=ssl_context):
        print("Signalling server running on wss://0.0.0.0:8765")
        await asyncio.Future()  # run forever


if __name__ == "__main__":
    asyncio.run(main())
