# Natural Voice Chat for Luckfox Pico

A lightweight voice chat application that runs on the Luckfox Pico with natural conversation capabilities using Qwen AI.

## Features

- 🎤 **Voice Input**: Records audio from the built-in microphone
- 🗣️ **Speech-to-Text**: Fast transcription using Groq Whisper API
- 🤖 **AI Conversation**: Natural dialogue with Qwen model
- 🔊 **Text-to-Speech**: High-quality voice output using DashScope CosyVoice
- 💬 **Conversation Memory**: Maintains context across exchanges

## Architecture

```
Microphone → arecord → WAV → Groq Whisper → Text → Qwen → Reply → CosyVoice → MP3 → ffmpeg → WAV → aplay → Speaker
```

## Requirements

- Luckfox Pico with:
  - Python 3.11+
  - Working microphone and speaker (rv1106-acodec)
  - WiFi or network connectivity
  - ffmpeg installed
- API Keys:
  - Groq API key (for Whisper transcription)
  - DashScope API key (for Qwen + CosyVoice)

## Setup

1. **Copy files to Luckfox Pico:**
   ```bash
   scp voice_chat.py setup.sh big:~/
   ```

2. **SSH into Luckfox Pico:**
   ```bash
   ssh big
   ```

3. **Run setup script:**
   ```bash
   chmod +x setup.sh
   ./setup.sh
   ```

4. **Set API keys:**
   ```bash
   export GROQ_API_KEY='your-groq-api-key-here'
   export DASHSCOPE_API_KEY='your-dashscope-api-key-here'
   ```

## Usage

Run the voice chat application:

```bash
python3 voice_chat.py
```

### How to use:

1. The app will start and wait for you to speak
2. Speak into the microphone (up to 10 seconds)
3. Wait for transcription and AI response
4. Listen to the spoken reply through the speaker
5. Continue the conversation naturally
6. Say "exit", "quit", "stop", or "goodbye" to end

### Example conversation:

```
🎙️  Natural Voice Chat Started
==================================================
Speak to start a conversation
Say 'exit', 'quit', or 'stop' to end
==================================================

🎤 Recording... (speak now, press Ctrl+C to stop)
✓ Recording complete
🔄 Transcribing audio...
✓ Transcription: What's the weather like today?
🤖 Thinking...
✓ Reply: I don't have access to real-time weather data, but I can help you find weather information if you tell me your location.
🔊 Generating speech...
✓ Speech generated

--------------------------------------------------

🎤 Recording... (speak now, press Ctrl+C to stop)
...
```

## Configuration

Edit `voice_chat.py` to customize:

- **Qwen model**: Change `qwen_model` (options: `qwen-turbo`, `qwen-plus`, `qwen-max`)
- **TTS voice**: Change `tts_voice` (options: `longxiaochun`, `longxiaoxia`, `longshu`, etc.)
- **System prompt**: Modify `system_prompt` to change assistant personality
- **Max tokens**: Adjust `max_tokens` for longer/shorter responses
- **Recording duration**: Change `-d 10` in `record_audio()` for different max length

## Troubleshooting

### No microphone detected
```bash
arecord -l  # List capture devices
cat /proc/asound/cards  # Check sound cards
```

### Audio recording fails
```bash
# Test manual recording
arecord -d 3 -f S16_LE -r 16000 test.wav
aplay test.wav
```

### API errors
- Verify API keys are set correctly
- Check network connectivity: `ping 8.8.8.8`
- Verify API quotas and limits

### TTS conversion fails
- Ensure ffmpeg is installed: `ffmpeg -version`
- Check available disk space: `df -h /tmp`

## Performance Notes

- **Latency**: ~3-5 seconds total (recording + transcription + AI + TTS)
- **Memory**: Uses ~30-40 MB RAM during operation
- **Network**: Requires stable internet connection for API calls
- **Audio quality**: 16kHz mono for optimal Whisper performance

## API Costs

- **Groq Whisper**: Free tier available, then ~$0.006/minute
- **Qwen Turbo**: ~$0.002 per 1K tokens
- **CosyVoice**: ~$0.0004 per 100 characters

## License

MIT License - Feel free to modify and distribute

## Support

For issues with:
- Luckfox Pico hardware: Check official Luckfox documentation
- Groq API: https://console.groq.com/docs
- DashScope API: https://dashscope.aliyun.com/
