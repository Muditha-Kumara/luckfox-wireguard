#!/bin/bash
# Setup script for Natural Voice Chat on Luckfox Pico

echo "🔧 Setting up Natural Voice Chat..."

# Create temp directory
mkdir -p /tmp/voice_chat

# Install required Python packages
echo "📦 Installing Python dependencies..."
pip3 install aiohttp

# Test audio hardware
echo "🎤 Testing audio hardware..."
if arecord -l | grep -q "card"; then
    echo "✓ Microphone detected"
else
    echo "❌ No microphone found"
    exit 1
fi

if aplay -l | grep -q "card"; then
    echo "✓ Speaker detected"
else
    echo "❌ No speaker found"
    exit 1
fi

# Quick audio test
echo "🔊 Running quick audio test..."
arecord -d 2 -f S16_LE -r 16000 /tmp/test_mic.wav
if [ $? -eq 0 ]; then
    echo "✓ Recording works"
    aplay /tmp/test_mic.wav
    echo "✓ Playback works"
    rm /tmp/test_mic.wav
else
    echo "❌ Audio test failed"
    exit 1
fi

# Check for ffmpeg
if ! command -v ffmpeg &> /dev/null; then
    echo "⚠️  ffmpeg not found. TTS conversion may fail."
else
    echo "✓ ffmpeg available"
fi

echo ""
echo "✅ Setup complete!"
echo ""
echo "To run the voice chat:"
echo "  export GROQ_API_KEY='your-groq-api-key'"
echo "  export DASHSCOPE_API_KEY='your-dashscope-api-key'"
echo "  python3 voice_chat.py"
