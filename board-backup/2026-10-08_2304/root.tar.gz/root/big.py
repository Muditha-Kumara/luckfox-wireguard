import asyncio
import websockets
import ssl
import json
import http.server
import socketserver
import threading

# 1. Serve the HTML page over standard HTTPS
class Handler(http.server.SimpleHTTPRequestHandler):
    pass

def start_http():
    httpd = socketserver.TCPServer(("", 4433), Handler)
    httpd.socket = ssl.wrap_socket(httpd.socket, certfile='./cert.pem', keyfile='./key.pem', server_side=True)
    httpd.serve_forever()

threading.Thread(target=start_http, daemon=True).start()

# 2. WebSocket Signaling Server for WebRTC
connected_clients = set()

async def signaling_handler(websocket, path):
    connected_clients.add(websocket)
    try:
        async for message in websocket:
            # Broadcast the signaling message to the OTHER client
            for client in connected_clients:
                if client != websocket:
                    await client.send(message)
    finally:
        connected_clients.remove(websocket)

ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ssl_context.load_cert_chain(certfile='./cert.pem', keyfile='./key.pem')

start_server = websockets.serve(signaling_handler, "0.0.0.0", 8765, ssl=ssl_context)

print("Server running. Access the web app at https://<PICO_WIREGUARD_IP>:4433")
asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()
