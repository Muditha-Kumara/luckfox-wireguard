#!/usr/bin/env python3
"""
Real-time Voice Chat — Qwen Audio 3.0 Realtime Flash
Uses: qwen-audio-3.0-realtime-flash over WebSocket (full-duplex, single model)
Audio: arecord / aplay subprocess pipes (no pyaudio needed — works on Luckfox)
Ref:  https://modelstudio.console.alibabacloud.com/
"""

import asyncio
import asyncio.subprocess
import base64
import json
import os
import signal
import sys
import time
import traceback

import websockets

# ─── Configuration ───────────────────────────────────────────────
# API key: prefer environment variable, fall back to built-in key
DASHSCOPE_API_KEY = os.environ.get(
    "DASHSCOPE_API_KEY",
    "sk-ws-H.DMYEEHD.DtHr.MEQCIEyrRNZye_zWxV2aBEYz6XtE0Bgq-i1fK28NzqTYI2h3AiAnxt9E5DFg8rjsWo8sU9TSspzVz8Vog2JMXDppwKvufg"
)

WORKSPACE_ID = "ws-i0snezt6phe9ll9c"
REGION       = "ap-southeast-1"
MODEL        = "qwen-audio-3.0-realtime-flash"

URL = (
    f"wss://{WORKSPACE_ID}.{REGION}.maas.aliyuncs.com"
    f"/api-ws/v1/realtime?model={MODEL}"
)

# Audio settings
MIC_RATE      = 16000   # input sample rate
SPK_RATE      = 24000   # output sample rate
CHANNELS      = 1
CHUNK_SIZE    = 3200    # bytes per read (200 ms @ 16 kHz, 16-bit mono)

# Session config
VOICE         = "longanqian"
VAD_THRESHOLD = 0.5
SILENCE_DURATION_MS = 500


# ─── VoiceChat class ─────────────────────────────────────────────
class VoiceChat:
    """Real-time full-duplex voice chat with qwen-audio-3.0-realtime-flash."""

    def __init__(self):
        self.mic_proc = None    # arecord subprocess
        self.spk_proc = None    # aplay subprocess
        self.ws = None
        self._running = False
        self._session_start = 0.0

    # ─── Audio device helpers ─────────────────────────────────
    async def open_devices(self):
        """Open microphone (arecord) and speaker (aplay) as subprocess pipes."""
        # --- Microphone: arecord outputs raw PCM to stdout ---
        try:
            self.mic_proc = await asyncio.subprocess.create_subprocess_exec(
                "arecord",
                "-t", "raw",
                "-f", "S16_LE",
                "-r", str(MIC_RATE),
                "-c", str(CHANNELS),
                "-q",
                "-",                     # stdout
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            print("✓ Microphone opened (arecord, 16 kHz)")
        except FileNotFoundError:
            print("❌ arecord not found — install alsa-utils")
            raise
        except Exception as e:
            print(f"❌ Cannot open microphone: {e}")
            raise

        # --- Speaker: aplay reads raw PCM from stdin ---
        try:
            self.spk_proc = await asyncio.subprocess.create_subprocess_exec(
                "aplay",
                "-t", "raw",
                "-f", "S16_LE",
                "-r", str(SPK_RATE),
                "-c", str(CHANNELS),
                "-q",
                "-",                     # stdin
                stdin=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            print("✓ Speaker opened (aplay, 24 kHz)")
        except FileNotFoundError:
            print("❌ aplay not found — install alsa-utils")
            raise
        except Exception as e:
            print(f"❌ Cannot open speaker: {e}")
            raise

    async def close_devices(self):
        """Safely terminate audio subprocesses."""
        for proc, name in [(self.mic_proc, "mic"), (self.spk_proc, "speaker")]:
            if proc is not None:
                try:
                    proc.terminate()
                    await asyncio.wait_for(proc.wait(), timeout=2)
                except (asyncio.TimeoutError, ProcessLookupError):
                    try:
                        proc.kill()
                    except ProcessLookupError:
                        pass
                except Exception:
                    pass
        self.mic_proc = None
        self.spk_proc = None

    async def _read_mic_chunk(self) -> bytes:
        """Read exactly CHUNK_SIZE bytes from the mic pipe."""
        return await self.mic_proc.stdout.readexactly(CHUNK_SIZE)

    async def _write_spk(self, data: bytes):
        """Write audio data to the speaker pipe."""
        self.spk_proc.stdin.write(data)
        await self.spk_proc.stdin.drain()

    # ─── WebSocket event handlers ─────────────────────────────
    async def send_audio(self):
        """Continuously read mic pipe and send audio chunks to server."""
        while self._running:
            try:
                data = await self._read_mic_chunk()
                payload = json.dumps({
                    "type": "input_audio_buffer.append",
                    "audio": base64.b64encode(data).decode("ascii"),
                })
                await self.ws.send(payload)
                await asyncio.sleep(0.02)  # ~50 Hz send rate
            except websockets.exceptions.ConnectionClosed:
                break
            except asyncio.IncompleteReadError:
                print("  ⚠️  Mic stream ended")
                break
            except Exception as e:
                print(f"  ⚠️  Mic send error: {e}")
                break

    async def recv_events(self):
        """Receive and handle server events."""
        async for raw in self.ws:
            try:
                event = json.loads(raw)
            except json.JSONDecodeError:
                continue

            etype = event.get("type", "")

            if etype == "response.audio.delta":
                audio = base64.b64decode(event["delta"])
                try:
                    await self._write_spk(audio)
                except Exception:
                    pass  # speaker pipe may have closed

            elif etype == "conversation.item.input_audio_transcription.completed":
                transcript = event.get("transcript", "")
                print(f"\n  🎤 [You]  {transcript}")

            elif etype == "response.audio_transcript.done":
                transcript = event.get("transcript", "")
                print(f"  🤖 [AI]   {transcript}")

            elif etype == "response.done":
                usage = event.get("response", {}).get("usage", {})
                if usage:
                    in_tok = usage.get("input_tokens", "?")
                    out_tok = usage.get("output_tokens", "?")
                    print(f"  📊 tokens: in={in_tok} out={out_tok}")

            elif etype == "error":
                msg = event.get("error", {}).get("message", "unknown error")
                print(f"  ❌ Server error: {msg}")

            elif etype == "session.created":
                session_id = event.get("session", {}).get("id", "?")
                print(f"  ✓ Session created: {session_id[:20]}...")

            # Other events are silently ignored

    # ─── Main session ──────────────────────────────────────────
    async def connect_and_run(self):
        """Connect to WebSocket, configure session, start send/recv loops."""
        headers = {"Authorization": f"Bearer {DASHSCOPE_API_KEY}"}

        print(f"  Connecting to {MODEL}...")
        print(f"  Endpoint: wss://{WORKSPACE_ID}.{REGION}.maas.aliyuncs.com/...")

        async with websockets.connect(URL, additional_headers=headers) as ws:
            self.ws = ws

            session_config = {
                "type": "session.update",
                "session": {
                    "modalities": ["text", "audio"],
                    "voice": VOICE,
                    "turn_detection": {
                        "type": "server_vad",
                        "threshold": VAD_THRESHOLD,
                        "silence_duration_ms": SILENCE_DURATION_MS,
                    },
                },
            }
            await ws.send(json.dumps(session_config))
            print("  ✓ Session configured (VAD + audio)")
            print()

            self._running = True
            self._session_start = time.time()

            await asyncio.gather(
                self.send_audio(),
                self.recv_events(),
            )

    async def run(self):
        """Top-level entry: open devices, run session, handle cleanup."""
        print()
        print("=" * 55)
        print("  🎙️  Real-time Voice Chat — Qwen Audio 3.0 Realtime")
        print("=" * 55)
        print(f"  Model  : {MODEL}")
        print(f"  Voice  : {VOICE}")
        print(f"  VAD    : server_vad (threshold={VAD_THRESHOLD}, "
              f"silence={SILENCE_DURATION_MS}ms)")
        print("=" * 55)
        print("  Start speaking — the AI responds in real time.")
        print("  Press Ctrl+C to exit.")
        print("=" * 55)
        print()

        await self.open_devices()

        try:
            await self.connect_and_run()
        except websockets.exceptions.ConnectionClosed as e:
            print(f"\n⚠️  Connection closed: {e}")
        except Exception:
            traceback.print_exc()
        finally:
            self._running = False
            elapsed = time.time() - self._session_start
            print(f"\n  ⏱️  Session lasted {elapsed:.0f}s")
            await self.close_devices()
            print("  👋 Session ended.")


# ─── Entry point ─────────────────────────────────────────────────
async def main():
    chat = VoiceChat()
    await chat.run()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n👋 Interrupted. Goodbye!")
