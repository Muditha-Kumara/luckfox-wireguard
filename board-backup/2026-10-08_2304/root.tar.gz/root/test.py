#!/usr/bin/env python3
import http.server
import socketserver
import ssl
import sys

PORT = 8080
HTML_CONTENT = """<!DOCTYPE html>
<html>
<head>
    <title>VPN Connectivity Test</title>
    <style>
        body { font-family: sans-serif; text-align: center; margin-top: 50px; background: #111; color: #fff; }
        h1 { color: #4caf50; }
        .box { background: #222; padding: 20px; border-radius: 10px; display: inline-block; border: 1px solid #333; }
    </style>
</head>
<body>
    <div class="box">
        <h1>✅ Connection Successful</h1>
        <p>If you see this, your Luckfox is reachable over the VPN!</p>
        <p>Protocol: <b id="proto"></b></p>
        <p>Port: <b>8080</b></p>
    </div>
    <script>
        document.getElementById('proto').innerText = window.location.protocol;
    </script>
</body>
</html>
"""

class TestHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(HTML_CONTENT.encode('utf-8'))

    def log_message(self, format, *args):
        # Prints to the Luckfox console so you can see the connection arrive
        print(f"[CLIENT CONNECTED] {self.client_address[0]}")

def run_server(use_https=False):
    with socketserver.TCPServer(("0.0.0.0", PORT), TestHandler) as httpd:
        if use_https:
            print(f"[*] Starting HTTPS test server on port {PORT}...")
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            # Uses the same certificates you already SCP'd for your audio server
            context.load_cert_chain(certfile="/root/cert.pem", keyfile="/root/key.pem")
            httpd.socket = context.wrap_socket(httpd.socket, server_side=True)
        else:
            print(f"[*] Starting HTTP test server on port {PORT}...")
            
        print(f"[*] Open your browser and go to: {'https' if use_https else 'http'}://<YOUR_VPN_IP>:8080")
        httpd.serve_forever()

if __name__ == "__main__":
    # Run with 'python3 test_server.py https' to test SSL
    use_ssl = len(sys.argv) > 1 and sys.argv[1].lower() == 'https'
    run_server(use_https=use_ssl)
