#!/usr/bin/env python3
"""
Quick test for DashScope API connectivity and audio hardware
"""

import asyncio
import aiohttp
import subprocess
import os
from pathlib import Path

# Your DashScope credentials
DASHSCOPE_API_KEY = "sk-ws-H.DMYEEHD.DtHr.MEQCIEyrRNZye_zWxV2aBEYz6XtE0Bgq-i1fK28NzqTYI2h3AiAnxt9E5DFg8rjsWo8sU9TSspzVz8Vog2JMXDppwKvufg"
DASHSCOPE_BASE    = "https://ws-i0snezt6phe9ll9c.ap-southeast-1.maas.aliyuncs.com"
OPENAI_COMPAT     = f"{DASHSCOPE_BASE}/compatible-mode/v1"
DASHSCOPE_API     = f"{DASHSCOPE_BASE}/api/v1"

async def test_qwen_api():
    """Test Qwen chat API"""
    print("\n🤖 Testing Qwen API...")
    
    url = f"{OPENAI_COMPAT}/chat/completions"
    headers = {
        "Authorization": f"Bearer {DASHSCOPE_API_KEY}",
        "Content-Type": "application/json",
    }
    
    payload = {
        "model": "qwen-turbo",
        "messages": [
            {"role": "user", "content": "Say hello in one sentence."}
        ],
        "max_tokens": 50,
    }
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(url, json=payload, headers=headers) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    reply = result["choices"][0]["message"]["content"]
                    print(f"✓ Qwen API works! Reply: {reply}")
                    return True
                else:
                    error = await resp.text()
                    print(f"❌ Qwen API failed ({resp.status}): {error[:200]}")
                    return False
        except Exception as e:
            print(f"❌ Qwen API error: {e}")
            return False

async def test_tts_api():
    """Test CosyVoice TTS API"""
    print("\n🔊 Testing TTS API...")
    
    url = f"{DASHSCOPE_API}/services/aigc/text2audio/generation"
    headers = {
        "Authorization": f"Bearer {DASHSCOPE_API_KEY}",
        "Content-Type": "application/json",
    }
    
    payload = {
        "model": "cosyvoice-v1",
        "input": {
            "text": "Hello, this is a test."
        },
        "parameters": {
            "voice": "longxiaochun",
            "format": "mp3",
            "sample_rate": 16000
        }
    }
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(url, json=payload, headers=headers) as resp:
                if resp.status == 200:
                    audio_data = await resp.read()
                    print(f"✓ TTS API works! Generated {len(audio_data)} bytes of audio")
                    
                    # Save and convert to WAV
                    with open("/tmp/test_tts.mp3", "wb") as f:
                        f.write(audio_data)
                    
                    subprocess.run(
                        ["ffmpeg", "-y", "-i", "/tmp/test_tts.mp3",
                         "-ar", "16000", "-ac", "1", "/tmp/test_tts.wav"],
                        check=True, capture_output=True
                    )
                    
                    # Play it
                    print("  Playing test audio...")
                    subprocess.run(["aplay", "-q", "/tmp/test_tts.wav"], 
                                 capture_output=True)
                    
                    # Cleanup
                    os.remove("/tmp/test_tts.mp3")
                    os.remove("/tmp/test_tts.wav")
                    
                    return True
                else:
                    error = await resp.text()
                    print(f"❌ TTS API failed ({resp.status}): {error[:200]}")
                    return False
        except Exception as e:
            print(f"❌ TTS API error: {e}")
            return False

def test_audio_hardware():
    """Test microphone and speaker"""
    print("\n🎤 Testing audio hardware...")
    
    # Test recording
    try:
        subprocess.run(
            ["arecord", "-d", "2", "-f", "S16_LE", "-r", "16000", 
             "-c", "1", "-q", "/tmp/test_mic.wav"],
            check=True, capture_output=True, timeout=5
        )
        size = os.path.getsize("/tmp/test_mic.wav")
        print(f"✓ Microphone works! Recorded {size} bytes")
        
        # Test playback
        subprocess.run(["aplay", "-q", "/tmp/test_mic.wav"], 
                      check=True, capture_output=True)
        print("✓ Speaker works!")
        
        os.remove("/tmp/test_mic.wav")
        return True
    except Exception as e:
        print(f"❌ Audio hardware error: {e}")
        return False

async def main():
    print("=" * 50)
    print("  DashScope API & Audio Hardware Test")
    print("=" * 50)
    
    results = []
    
    # Test audio hardware
    results.append(("Audio Hardware", test_audio_hardware()))
    
    # Test Qwen API
    results.append(("Qwen API", await test_qwen_api()))
    
    # Test TTS API
    results.append(("TTS API", await test_tts_api()))
    
    # Summary
    print("\n" + "=" * 50)
    print("  Test Summary")
    print("=" * 50)
    for name, passed in results:
        status = "✓ PASS" if passed else "❌ FAIL"
        print(f"  {status} - {name}")
    
    all_passed = all(r[1] for r in results)
    print("=" * 50)
    
    if all_passed:
        print("\n✅ All tests passed! Ready to run voice_chat.py")
    else:
        print("\n⚠️  Some tests failed. Check the errors above.")

if __name__ == "__main__":
    asyncio.run(main())
