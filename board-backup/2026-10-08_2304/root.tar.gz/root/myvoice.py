#!/usr/bin/env python3
import asyncio
import websockets
import subprocess
import threading
import queue
import ssl
import sys
from http.server import SimpleHTTPRequestHandler
from socketserver import TCPServer

# --- HARDWARE CONFIGURATION ---
SAMPLE_RATE = "16000"
FORMAT = "S16_LE"
CHUNK_SIZE = 1024
PLAYBACK_CHANNELS = "2"
RECORD_CHANNELS = "2"
AUDIO_DEVICE = "default"

speaker_queue = queue.Queue()

# --- HARDWARE GAIN OVERRIDE ---
def set_hardware_speaker_volume(pct):
    alsa_val = int((pct / 100.0) * 30)
    alsa_val = max(0, min(30, alsa_val))
    cmd = ["amixer", "cset", "name=DAC LINEOUT Volume", str(alsa_val)]
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def optimize_hardware_volumes():
    commands = [
        ["amixer", "cset", "name=DAC LINEOUT Volume", "24"],
        ["amixer", "cset", "name=ACodec ADC Boost Gain", "3"],
        ["amixer", "cset", "name=ACodec ADC ALC PGA Gain", "240"],
        ["amixer", "cset", "name=ACodec ADC Digital Gain", "220"]
    ]
    for cmd in commands:
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# --- PLAYBACK LOOP ENGINE ---
def run_aplay():
    cmd = ["aplay", "-D", AUDIO_DEVICE, "-r", SAMPLE_RATE, "-c", PLAYBACK_CHANNELS, "-f", FORMAT, "-t", "raw", "--buffer-time=40000", "--period-time=10000", "-"]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.DEVNULL)
    while True:
        data = speaker_queue.get()
        if data is None: break
        try: proc.stdin.write(data); proc.stdin.flush()
        except: break
    proc.terminate()

# --- WEB CONTENT ---
HTML_CONTENT = """<!DOCTYPE html><html><body>
<script>
    const ws = new WebSocket("wss://" + window.location.hostname + ":8765");
</script></body></html>"""

class EmbeddedHTTPHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200); self.send_header("Content-type", "text/html"); self.end_headers()
        self.wfile.write(HTML_CONTENT.encode("utf-8"))

def start_web_server():
    httpd = TCPServer(("0.0.0.0", 8080), EmbeddedHTTPHandler)
    ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ssl_context.load_cert_chain(certfile="/root/cert.pem", keyfile="/root/key.pem")
    httpd.socket = ssl_context.wrap_socket(httpd.socket, server_side=True)
    httpd.serve_forever()

# --- AUDIO ENGINE ---
async def audio_handler(websocket):
    session_state = {"mute_device_mic": False}
    cmd = ["arecord", "-D", AUDIO_DEVICE, "-r", SAMPLE_RATE, "-c", RECORD_CHANNELS, "-f", FORMAT, "-t", "raw"]
    proc_record = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    
    async def send_mic():
        while True:
            data = proc_record.stdout.read(CHUNK_SIZE * 2)
            if not data: break
            if not session_state["mute_device_mic"]: await websocket.send(data)

    async def receive_speaker():
        async for message in websocket:
            if isinstance(message, bytes): speaker_queue.put(message)
            elif isinstance(message, str):
                if message == "TALK_START": session_state["mute_device_mic"] = True
                elif message == "TALK_STOP": session_state["mute_device_mic"] = False
                elif message.startswith("SET_DEV_VOL:"): set_hardware_speaker_volume(int(message.split(":")[1]))

    await asyncio.gather(send_mic(), receive_speaker())
    proc_record.terminate()

async def main():
    optimize_hardware_volumes()
    ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ssl_context.load_cert_chain(certfile="/root/cert.pem", keyfile="/root/key.pem")

    threading.Thread(target=run_aplay, daemon=True).start()
    threading.Thread(target=start_web_server, daemon=True).start()
    
    async with websockets.serve(audio_handler, "0.0.0.0", 8765, ssl=ssl_context, origins=["*"]):
        await asyncio.Future()

if __name__ == "__main__":
    asyncio.run(main())
