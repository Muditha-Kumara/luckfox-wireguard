#!/usr/bin/env python3
"""
Real-time Voice Chat — Laptop Edition v2 (latency + token profiler)
Uses: qwen-audio-3.0-realtime-flash over WebSocket, arecord/aplay for audio

v2 improvements
---------------
* Per-turn REPLY TIMER: prints the ms between "you stopped speaking" and the
  first audio of the AI reply (reply_time_speech_end_to_1st_audio).
* Big input-token savings:
    - mic is paused while the AI speaks (no speaker feedback streamed back,
      no billing for silence while listening to a long answer)
    - client-side energy gate (CLIENT_VAD) so idle room silence is never
      streamed/billed at all
* 100ms chunks + tiny send queue → no more 10-second ws.send stalls.
* Clean Ctrl+C shutdown (no SSL 'Event loop is closed' errors).

No pyaudio required — works on any Linux laptop with alsa-utils.
"""

import array
import asyncio
import asyncio.subprocess
import base64
import json
import math
import os
import signal
import time
import traceback
from collections import defaultdict, deque
from dataclasses import dataclass, field

import websockets

# ─── Configuration ───────────────────────────────────────────────
DASHSCOPE_API_KEY = os.environ.get(
    "DASHSCOPE_API_KEY",
    "sk-ws-H.DMXDLYE.FBOR.MEQCIHf83DicflhAH1V152AFGE4xM5qcONrK6T49ypviMa5vAiBivBOMk8ZeLry6-LlyZPrcXFnZP1EqwA-_X4j3R9vhbw"
)

WORKSPACE_ID = "ws-047evhyj8bxtjdxs"
REGION       = "ap-southeast-1"
MODEL        = "qwen-audio-3.0-realtime-flash"

URL = (
    f"wss://{WORKSPACE_ID}.{REGION}.maas.aliyuncs.com"
    f"/api-ws/v1/realtime?model={MODEL}"
)

# Audio settings
MIC_RATE      = 16000
SPK_RATE      = 24000
CHANNELS      = 1
CHUNK_MS      = 100              # was 200ms → fresher audio, ~100ms less delay
CHUNK_SAMPLES = int(MIC_RATE * CHUNK_MS / 1000)
SAMPLE_WIDTH  = 2
CHUNK_BYTES   = CHUNK_SAMPLES * SAMPLE_WIDTH

# Session config
VOICE               = "longanqian"
VAD_THRESHOLD       = 0.5
SILENCE_DURATION_MS = 400        # silence needed before the AI starts to
                                 # answer. Lower = faster reply, but pauses
                                 # in your speech may split a sentence.
PREFIX_PADDING_MS   = 300        # audio kept from just before speech start

# ─── Latency & input-token saving tuning ─────────────────────────
MIC_PAUSE_WHILE_AI_SPEAKS = True  # don't stream the mic while the AI talks:
                                  # saves input tokens and stops the AI from
                                  # hearing itself (no more echo transcripts)
ALLOW_BARGE_IN            = False # True = mic stays live so you can
                                  # interrupt the AI mid-sentence
AI_TAIL_HOLD_S            = 1.2   # keep mic muted this long after the AI
                                  # finishes so the speaker tail is not
                                  # re-streamed as input
CLIENT_VAD                = True  # only stream chunks containing voice energy
                                  # → idle room silence costs zero tokens
CLIENT_VAD_THRESHOLD      = 350   # RMS (0-32767) treated as speech. Raise it
                                  # if background noise triggers streaming.
CLIENT_VAD_TAIL_MS        = 900   # silence streamed after voice stops (must be
                                  # > SILENCE_DURATION_MS so server can commit)
CLIENT_VAD_PREROLL        = 3     # chunks buffered so word starts aren't cut
SEND_QUEUE_MAX            = 8     # ~0.8s of audio; older chunks get dropped
                                  # when the network stalls (prevents the 10s+
                                  # ws.send backlogs seen before)
STARTUP_GRACE_MS          = 300   # discard first ms of mic (power-on pop)
SUMMARY_INTERVAL_S        = 10.0


# ─── Latency tracker ─────────────────────────────────────────────
@dataclass
class LatencyTracker:
    """Collects per-step latency samples and prints periodic summaries."""

    samples: dict = field(default_factory=lambda: defaultdict(list))
    _audio_send_times: dict = field(default_factory=dict)

    # Cumulative counters — NOT reset by summary()/reset()
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    turns: int = 0
    dropped_send_chunks: int = 0

    def add_tokens(self, in_tok: int, out_tok: int):
        self.total_input_tokens += int(in_tok or 0)
        self.total_output_tokens += int(out_tok or 0)

    def record(self, step: str, latency_ms: float):
        self.samples[step].append(latency_ms)

    def record_audio_sent(self, chunk_id: int):
        self._audio_send_times[chunk_id] = time.time()

    def record_transcription(self, chunk_id: int):
        sent = self._audio_send_times.pop(chunk_id, None)
        if sent is not None:
            self.record("e2e_transcription", (time.time() - sent) * 1000)

    def record_response_audio(self, chunk_id: int):
        sent = self._audio_send_times.pop(chunk_id, None)
        if sent is not None:
            self.record("e2e_response_audio", (time.time() - sent) * 1000)

    def summary(self) -> str:
        if not self.samples:
            return "  (no samples yet)"
        lines = []
        for step in sorted(self.samples.keys()):
            vals = self.samples[step]
            if not vals:
                continue
            avg = sum(vals) / len(vals)
            mn, mx = min(vals), max(vals)
            p50 = sorted(vals)[len(vals) // 2]
            p95 = sorted(vals)[int(len(vals) * 0.95)]
            lines.append(
                f"  {step:<30s}  avg={avg:7.1f} ms  "
                f"min={mn:6.1f}  p50={p50:6.1f}  p95={p95:6.1f}  n={len(vals)}"
            )
        return "\n".join(lines)

    def reset(self):
        self.samples.clear()
        self._audio_send_times.clear()


# ─── VoiceChat (Laptop) class ────────────────────────────────────
class VoiceChat:
    """Real-time voice chat with arecord/aplay and per-step latency profiling."""

    def __init__(self):
        self.mic_proc = None
        self.spk_proc = None
        self.ws = None
        self._running = False
        self._session_start = 0.0
        self._chunk_id = 0
        self.latency = LatencyTracker()
        self._last_summary = 0.0
        self._stop_event = asyncio.Event()      # set by Ctrl+C (SIGINT)
        # ── per-turn reply-time tracking ──
        self._speech_start_ts = None    # server VAD heard speech begin
        self._speech_stop_ts = None     # server VAD heard speech end
        self._first_audio_ts = None     # first AI audio chunk of this turn
        # ── token-saving state ──
        self._ai_speaking = False       # True → mic chunks are dropped
        self._mic_mute_until = 0.0      # hold mic closed after AI finishes
        self._resp_audio_bytes = 0      # AI audio received this response
        self._resp_first_write_ts = None  # when first AI audio hit the queue
        self._client_voice = False      # client energy gate: voice present?
        self._last_voice_ts = 0.0
        self._last_user_item_id = None  # last committed user audio item
        self._last_speech_ms = 0
        self._clear_supported = True
        # Send queue: decouples mic reading from ws.send so network latency
        # doesn't block the recv loop or mic capture. Kept SMALL on purpose:
        # when the network stalls, old audio is dropped instead of building
        # up a multi-second backlog (that caused the 10s ws_send stalls).
        self._send_queue: asyncio.Queue = asyncio.Queue(maxsize=SEND_QUEUE_MAX)
        self._spk_queue: asyncio.Queue = asyncio.Queue(maxsize=100)

    async def open_devices(self):
        """Open microphone (arecord) and speaker (aplay) as subprocess pipes."""
        try:
            self.mic_proc = await asyncio.subprocess.create_subprocess_exec(
                "arecord", "-t", "raw", "-f", "S16_LE",
                "-r", str(MIC_RATE), "-c", str(CHANNELS), "-q", "-",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            print(f"  ✓ Microphone opened (arecord, {MIC_RATE} Hz)")
        except FileNotFoundError:
            print("  ❌ arecord not found — install alsa-utils")
            raise
        except Exception as e:
            print(f"  ❌ Cannot open microphone: {e}")
            raise

        try:
            self.spk_proc = await asyncio.subprocess.create_subprocess_exec(
                "aplay", "-t", "raw", "-f", "S16_LE",
                "-r", str(SPK_RATE), "-c", str(CHANNELS), "-q", "-",
                stdin=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            print(f"  ✓ Speaker opened (aplay, {SPK_RATE} Hz)")
        except FileNotFoundError:
            print("  ❌ aplay not found — install alsa-utils")
            raise
        except Exception as e:
            print(f"  ❌ Cannot open speaker: {e}")
            raise

    async def close_devices(self):
        """Safely terminate audio subprocesses (await every wait())."""
        # close aplay's stdin first so it can finish buffered audio
        if self.spk_proc is not None and self.spk_proc.stdin is not None:
            try:
                self.spk_proc.stdin.close()
            except Exception:
                pass
        for proc in (self.mic_proc, self.spk_proc):
            if proc is None:
                continue
            try:
                proc.terminate()
            except ProcessLookupError:
                continue
            try:
                await asyncio.wait_for(proc.wait(), timeout=2)
            except asyncio.TimeoutError:
                try:
                    proc.kill()
                except ProcessLookupError:
                    continue
                try:
                    await asyncio.wait_for(proc.wait(), timeout=1)
                except (asyncio.TimeoutError, ProcessLookupError):
                    pass
            except Exception:
                pass
        self.mic_proc = None
        self.spk_proc = None

    async def read_mic_chunk(self) -> bytes:
        t0 = time.time()
        data = await self.mic_proc.stdout.readexactly(CHUNK_BYTES)
        self.latency.record("mic_read", (time.time() - t0) * 1000)
        return data

    async def write_spk(self, data: bytes):
        """Queue audio for the speaker writer task (non-blocking)."""
        try:
            self._spk_queue.put_nowait(data)
        except asyncio.QueueFull:
            # Drop oldest chunk to avoid blocking the recv loop
            try:
                self._spk_queue.get_nowait()
            except asyncio.QueueEmpty:
                pass
            self._spk_queue.put_nowait(data)

    async def spk_writer_loop(self):
        """Dedicated speaker writer — drains queue to aplay without blocking recv."""
        while self._running:
            try:
                data = await asyncio.wait_for(self._spk_queue.get(), timeout=0.5)
            except asyncio.TimeoutError:
                continue
            except Exception:
                break
            t0 = time.time()
            try:
                self.spk_proc.stdin.write(data)
                await self.spk_proc.stdin.drain()
            except Exception:
                pass
            self.latency.record("spk_write", (time.time() - t0) * 1000)

    async def send_audio_chunk(self, data: bytes):
        t0 = time.time()
        payload = json.dumps({
            "type": "input_audio_buffer.append",
            "audio": base64.b64encode(data).decode("ascii"),
        })
        self.latency.record("base64_encode", (time.time() - t0) * 1000)

        # Put payload on the send queue instead of awaiting ws.send directly.
        # This keeps the mic loop fast even when the network is slow.
        t1 = time.time()
        try:
            self._send_queue.put_nowait(payload)
        except asyncio.QueueFull:
            # Network is behind: drop the OLDEST chunk so the server always
            # gets the freshest audio (old audio only adds latency + tokens).
            try:
                self._send_queue.get_nowait()
                self.latency.dropped_send_chunks += 1
            except asyncio.QueueEmpty:
                pass
            self._send_queue.put_nowait(payload)
        self.latency.record("ws_send", (time.time() - t1) * 1000)

        self._chunk_id += 1
        self.latency.record_audio_sent(self._chunk_id)

    async def _enqueue(self, obj: dict):
        """Put a control message on the send queue (in order with audio)."""
        try:
            self._send_queue.put_nowait(json.dumps(obj))
        except asyncio.QueueFull:
            try:
                self._send_queue.get_nowait()
                self.latency.dropped_send_chunks += 1
            except asyncio.QueueEmpty:
                pass
            self._send_queue.put_nowait(json.dumps(obj))

    @staticmethod
    def _chunk_rms(data: bytes) -> float:
        """RMS energy of a 16-bit PCM chunk (0..32767)."""
        samples = array.array("h")
        samples.frombytes(data[: len(data) - (len(data) % 2)])
        if not samples:
            return 0.0
        acc = 0
        for s in samples:
            acc += s * s
        return math.sqrt(acc / len(samples))

    async def ws_sender_loop(self):
        """Dedicated WebSocket sender — drains queue so sends don't block recv."""
        while self._running:
            try:
                payload = await asyncio.wait_for(self._send_queue.get(), timeout=0.5)
            except asyncio.TimeoutError:
                continue
            except Exception:
                break
            t0 = time.time()
            try:
                await self.ws.send(payload)
            except websockets.exceptions.ConnectionClosed:
                break
            except Exception:
                pass
            self.latency.record("ws_send_actual", (time.time() - t0) * 1000)

    async def send_audio_loop(self):
        """Read mic chunks and queue them for sending.

        Two token-saving gates live here:
        1. While the AI is speaking we drain the mic but send nothing —
           otherwise the speaker output is fed straight back into the model
           and billed as input audio (that also caused the weird echo
           transcripts like "my hand have sandy").
        2. CLIENT_VAD: when the room is quiet we only stream chunks that
           contain real voice energy, so idle silence costs zero tokens.
        """
        grace_until = time.time() + STARTUP_GRACE_MS / 1000.0
        preroll = deque(maxlen=CLIENT_VAD_PREROLL)
        tail_s = CLIENT_VAD_TAIL_MS / 1000.0

        while self._running:
            try:
                data = await self.read_mic_chunk()
            except asyncio.IncompleteReadError:
                print("  ⚠️  Mic stream ended")
                break
            except Exception as e:
                print(f"  ⚠️  Mic read error: {e}")
                break

            if time.time() < grace_until:
                continue                      # discard mic power-on pop

            if self._ai_speaking or time.time() < self._mic_mute_until:
                # AI is talking (or its speaker tail is still playing):
                # keep the pipe drained but send nothing.
                preroll.clear()
                self._client_voice = False
                continue

            if not CLIENT_VAD:
                await self.send_audio_chunk(data)
                continue

            rms = self._chunk_rms(data)
            now = time.time()
            if self._client_voice:
                await self.send_audio_chunk(data)
                if rms >= CLIENT_VAD_THRESHOLD:
                    self._last_voice_ts = now
                elif now - self._last_voice_ts >= tail_s:
                    # voice ended: stop streaming and discard leftover
                    # silence so it can't be billed on the next turn
                    self._client_voice = False
                    await self._enqueue({"type": "input_audio_buffer.clear"})
            else:
                preroll.append(data)
                if rms >= CLIENT_VAD_THRESHOLD:
                    # voice just started: flush pre-roll so the first
                    # syllable isn't cut off, then stream live
                    self._client_voice = True
                    self._last_voice_ts = now
                    for buffered in preroll:
                        await self.send_audio_chunk(buffered)
                    preroll.clear()

    async def recv_events(self):
        async for raw in self.ws:
            t_recv = time.time()

            try:
                event = json.loads(raw)
            except json.JSONDecodeError:
                continue

            etype = event.get("type", "")

            if etype == "response.audio.delta":
                # ── reply timer: first AI audio after you stopped speaking ──
                if self._first_audio_ts is None:
                    self._first_audio_ts = time.time()
                    if self._speech_stop_ts is not None:
                        ttfa = (self._first_audio_ts - self._speech_stop_ts) * 1000
                        self.latency.record(
                            "reply_time_speech_end_to_1st_audio", ttfa)
                        print(f"\n  ⏱️  Reply audio started {ttfa:.0f} ms after "
                              f"you stopped speaking "
                              f"(you spoke {self._last_speech_ms / 1000:.1f}s)")
                t0 = time.time()
                audio = base64.b64decode(event["delta"])
                self.latency.record("audio_b64decode", (time.time() - t0) * 1000)
                # track how much audio the speaker still has to play
                self._resp_audio_bytes += len(audio)
                if self._resp_first_write_ts is None:
                    self._resp_first_write_ts = time.time()
                try:
                    await self.write_spk(audio)
                except Exception:
                    pass
                self.latency.record_response_audio(self._chunk_id)

            elif etype == "conversation.item.input_audio_transcription.completed":
                transcript = event.get("transcript", "")
                print(f"\n  🎤 [You]  {transcript}")
                self.latency.record_transcription(self._chunk_id)

            elif etype == "response.audio_transcript.done":
                transcript = event.get("transcript", "")
                print(f"  🤖 [AI]   {transcript}")

            elif etype == "input_audio_buffer.speech_started":
                self._speech_start_ts = time.time()

            elif etype == "input_audio_buffer.speech_stopped":
                self._speech_stop_ts = time.time()
                if self._speech_start_ts is not None:
                    dur_ms = (self._speech_stop_ts - self._speech_start_ts) * 1000
                    self._last_speech_ms = dur_ms
                    self.latency.record("user_speech_duration", dur_ms)
                    print(f"\n  🎤 (speech detected: {dur_ms / 1000:.1f}s — "
                          f"waiting for reply…)")

            elif etype == "conversation.item.created":
                # remember the latest user audio item (useful for debugging
                # and future history-management features)
                item = event.get("item", {})
                content = item.get("content") or []
                ctypes = [c.get("type") for c in content]
                if item.get("role") == "user" and "input_audio" in ctypes:
                    self._last_user_item_id = item.get("id")

            elif etype == "response.created":
                # AI started a reply → pause the mic so its own voice and
                # room silence are not streamed (and billed) as input audio.
                self._resp_audio_bytes = 0
                self._resp_first_write_ts = None
                if MIC_PAUSE_WHILE_AI_SPEAKS and not ALLOW_BARGE_IN:
                    self._ai_speaking = True
                    if self._clear_supported:
                        # drop any uncommitted leftover audio
                        await self._enqueue({"type": "input_audio_buffer.clear"})

            elif etype == "response.done":
                # AI finished GENERATING, but aplay may still have seconds of
                # buffered audio to play. Estimate the real remaining play
                # time and keep the mic closed until it is actually silent.
                self._ai_speaking = False
                now_ts = time.time()
                remaining = 0.0
                if self._resp_first_write_ts is not None:
                    total_dur = self._resp_audio_bytes / (SPK_RATE * SAMPLE_WIDTH)
                    played = now_ts - self._resp_first_write_ts
                    remaining = max(0.0, total_dur - played)
                self._mic_mute_until = now_ts + remaining + AI_TAIL_HOLD_S
                if self._first_audio_ts is not None:
                    self.latency.record(
                        "response_audio_duration",
                        (time.time() - self._first_audio_ts) * 1000)
                usage = event.get("response", {}).get("usage", {})
                if usage:
                    in_tok = usage.get("input_tokens", 0) or 0
                    out_tok = usage.get("output_tokens", 0) or 0
                    self.latency.add_tokens(in_tok, out_tok)
                    self.latency.turns += 1
                    print(f"  📊 tokens: in={in_tok} out={out_tok}   "
                          f"(session total: in={self.latency.total_input_tokens} "
                          f"out={self.latency.total_output_tokens})")
                # NOTE: tests showed this endpoint already bills only the
                # CURRENT turn's audio (turn1 in=265, turn2 in=310 with and
                # without conversation.item.truncate), so no history trimming
                # is needed — the big token savings come from not streaming
                # silence/speaker-echo in the first place.
                self._last_user_item_id = None
                self._first_audio_ts = None
                self._speech_stop_ts = None
                self._speech_start_ts = None

            elif etype == "session.updated":
                print("  ✓ Session settings confirmed by server")

            elif etype == "error":
                err = event.get("error", {})
                msg = str(err.get("message", "unknown error"))
                low = msg.lower()
                if ("input_audio_buffer.clear" in low
                        or ("clear" in low and "buffer" in low)):
                    self._clear_supported = False
                    print("  ⚠️  Server doesn't support "
                          "input_audio_buffer.clear — disabled it")
                else:
                    print(f"  ❌ Server error: {msg}")

            elif etype == "session.created":
                session_id = event.get("session", {}).get("id", "?")
                print(f"  ✓ Session created: {session_id[:20]}...")

            self.latency.record("ws_recv_dispatch", (time.time() - t_recv) * 1000)

    def _print_summary(self):
        lt = self.latency
        print("\n" + "-" * 55)
        print(f"  LATENCY SUMMARY (last {SUMMARY_INTERVAL_S:.0f}s)")
        print("-" * 55)
        print(lt.summary())
        print(f"\n  Session totals → turns={lt.turns}  "
              f"tokens in={lt.total_input_tokens} "
              f"out={lt.total_output_tokens}  "
              f"dropped_chunks={lt.dropped_send_chunks}")
        print("-" * 55)
        lt.reset()

    async def summary_loop(self):
        """Prints the latency summary every N seconds, even when the
        server is completely quiet (e.g. nobody is speaking)."""
        while self._running:
            await asyncio.sleep(SUMMARY_INTERVAL_S)
            if not self._running:
                break
            now = time.time()
            if now - self._last_summary >= SUMMARY_INTERVAL_S - 0.1:
                self._last_summary = now
                self._print_summary()

    async def _stop_watcher(self):
        """Returns when Ctrl+C is pressed so the session can shut down."""
        await self._stop_event.wait()
        print("\n  ⏹  Ctrl+C received — closing session cleanly…")

    async def connect_and_run(self):
        headers = {"Authorization": f"Bearer {DASHSCOPE_API_KEY}"}
        print(f"  Connecting to {MODEL}...")
        print(f"  Endpoint: wss://{WORKSPACE_ID}.{REGION}.maas.aliyuncs.com/...")

        t_conn_start = time.time()
        async with websockets.connect(URL, additional_headers=headers) as ws:
            self.ws = ws
            self.latency.record("ws_connect", (time.time() - t_conn_start) * 1000)

            session_config = {
                "type": "session.update",
                "session": {
                    "modalities": ["text", "audio"],
                    "voice": VOICE,
                    "turn_detection": {
                        "type": "server_vad",
                        "threshold": VAD_THRESHOLD,
                        "silence_duration_ms": SILENCE_DURATION_MS,
                        "prefix_padding_ms": PREFIX_PADDING_MS,
                    },
                },
            }
            await ws.send(json.dumps(session_config))
            print("  ✓ Session configured (VAD + audio)")
            print()

            self._running = True
            self._session_start = time.time()
            self._last_summary = time.time()

            tasks = [
                asyncio.ensure_future(self.send_audio_loop()),
                asyncio.ensure_future(self.ws_sender_loop()),
                asyncio.ensure_future(self.spk_writer_loop()),
                asyncio.ensure_future(self.recv_events()),
                asyncio.ensure_future(self.summary_loop()),
                asyncio.ensure_future(self._stop_watcher()),
            ]
            done, pending = await asyncio.wait(
                tasks, return_when=asyncio.FIRST_COMPLETED)

            # shut everything down in an orderly way (the websocket is then
            # closed by the context manager while the loop is still open —
            # this fixes the old 'Event loop is closed' SSL errors)
            self._running = False
            for task in pending:
                task.cancel()
            for task in pending:
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass
            for task in done:
                if task.cancelled():
                    continue
                exc = task.exception()
                if exc is None:
                    continue
                if isinstance(exc, websockets.exceptions.ConnectionClosed):
                    print(f"\n  Connection closed: {exc}")
                else:
                    raise exc

    async def run(self):
        print()
        print("=" * 55)
        print("  Voice Chat - Laptop Edition v2 (latency + tokens)")
        print("=" * 55)
        print(f"  Model   : {MODEL}")
        print(f"  Voice   : {VOICE}")
        print(f"  Chunk   : {CHUNK_MS}ms ({CHUNK_SAMPLES} samples)")
        print(f"  Mic Hz  : {MIC_RATE}   Spk Hz: {SPK_RATE}")
        print(f"  VAD     : server_vad (threshold={VAD_THRESHOLD}, "
              f"silence={SILENCE_DURATION_MS}ms)")
        print(f"  Mic paused while AI speaks : {MIC_PAUSE_WHILE_AI_SPEAKS}")
        print(f"  Client silence gate        : {CLIENT_VAD} "
              f"(RMS>={CLIENT_VAD_THRESHOLD})")
        print("=" * 55)
        print("  Start speaking - the AI responds in real time.")
        print("  ⏱️  Reply time is printed for every turn.")
        print("  Press Ctrl+C to exit.")
        print("=" * 55)
        print()

        # Graceful Ctrl+C: set a flag instead of killing the event loop
        # (fixes the 'Event loop is closed' SSL errors on exit).
        loop = asyncio.get_running_loop()

        def _on_signal():
            if self._stop_event.is_set():
                os._exit(130)          # second Ctrl+C: force quit
            self._stop_event.set()

        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, _on_signal)
            except (NotImplementedError, RuntimeError):
                pass

        await self.open_devices()

        try:
            await self.connect_and_run()
        except websockets.exceptions.ConnectionClosed as e:
            print(f"\n  Connection closed: {e}")
        except Exception:
            traceback.print_exc()
        finally:
            self._running = False
            elapsed = time.time() - self._session_start
            lt = self.latency
            print(f"\n  Session lasted {elapsed:.0f}s")
            print("\n  FINAL LATENCY SUMMARY")
            print("-" * 55)
            print(lt.summary())
            print(f"\n  Session totals → turns={lt.turns}  "
                  f"input_tokens={lt.total_input_tokens}  "
                  f"output_tokens={lt.total_output_tokens}  "
                  f"dropped_chunks={lt.dropped_send_chunks}")
            if lt.turns:
                print(f"  Avg input tokens per response: "
                      f"{lt.total_input_tokens / lt.turns:.0f}")
            print("-" * 55)
            await self.close_devices()
            for sig in (signal.SIGINT, signal.SIGTERM):
                try:
                    loop.remove_signal_handler(sig)
                except (NotImplementedError, RuntimeError):
                    pass
            print("  Session ended.")


async def main():
    chat = VoiceChat()
    await chat.run()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n  Interrupted. Goodbye!")
