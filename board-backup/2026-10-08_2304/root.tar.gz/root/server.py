import http.server
import socketserver
import ssl
import json

# Storage for WebRTC signaling data
offer_data = None
answer_data = None
ice_a = []
ice_b = []


class SignalingHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # Suppress default logging

    def do_POST(self):
        global offer_data, answer_data, ice_a, ice_b
        content_length = int(self.headers["Content-Length"])
        post_data = self.rfile.read(content_length)
        data = json.loads(post_data)

        if self.path == "/offer":
            offer_data = data
        elif self.path == "/answer":
            answer_data = data
        elif self.path == "/ice-a":
            ice_a.append(data)
        elif self.path == "/ice-b":
            ice_b.append(data)

        self.send_response(200)
        self.send_header("Content-type", "application/json")
        self.end_headers()
        self.wfile.write(b'{"status": "ok"}')

    def do_GET(self):
        global offer_data, answer_data, ice_a, ice_b

        # Handle API endpoints
        if self.path == "/offer":
            self.send_response(200)
            self.send_header("Content-type", "application/json")
            self.end_headers()
            res = offer_data if offer_data else None
            offer_data = None
            self.wfile.write(json.dumps(res).encode())

        elif self.path == "/answer":
            self.send_response(200)
            self.send_header("Content-type", "application/json")
            self.end_headers()
            res = answer_data if answer_data else None
            answer_data = None
            self.wfile.write(json.dumps(res).encode())

        elif self.path == "/ice-a":
            self.send_response(200)
            self.send_header("Content-type", "application/json")
            self.end_headers()
            res = list(ice_a)
            ice_a.clear()
            self.wfile.write(json.dumps(res).encode())

        elif self.path == "/ice-b":
            self.send_response(200)
            self.send_header("Content-type", "application/json")
            self.end_headers()
            res = list(ice_b)
            ice_b.clear()
            self.wfile.write(json.dumps(res).encode())

        else:
            # For standard web pages (like index.html), let the parent
            # class handle the headers and serve the file as text/html!
            super().do_GET()


class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    pass


if __name__ == "__main__":
    httpd = ThreadingHTTPServer(("0.0.0.0", 8000), SignalingHandler)
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile="cert.pem", keyfile="key.pem")
    httpd.socket = context.wrap_socket(httpd.socket, server_side=True)

    print("Walkie-Talkie Server running on https://0.0.0.0:8000")
    httpd.serve_forever()
